package com.example.anantprsd5.daggermvp.View;

public interface JokesView {
    void onJokesFetched(String joke);
}
