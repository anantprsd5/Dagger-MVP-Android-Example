package com.example.anantprsd5.daggermvp.Activities;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.anantprsd5.daggermvp.Model.JokesModel;
import com.example.anantprsd5.daggermvp.Presenter.JokesPresenter;
import com.example.anantprsd5.daggermvp.R;
import com.example.anantprsd5.daggermvp.View.JokesView;

import androidx.appcompat.app.AppCompatActivity;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity implements JokesView {

    @BindView(R.id.button)
    Button button;
    @BindView(R.id.textView)
    TextView textView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.bind(this);

        JokesModel jokesModel = new JokesModel();

        final JokesPresenter jokesPresenter = new JokesPresenter(jokesModel, this);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jokesPresenter.getJokes();
            }
        });
    }

    @Override
    public void onJokesFetched(String joke) {
        textView.setText(joke);
    }
}
